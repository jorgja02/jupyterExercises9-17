
# coding: utf-8

# In[2]:

get_ipython().magic('matplotlib inline')
import pandas as pd


# In[3]:

from IPython.core.display import HTML
css = open('style-table.css').read() + open('style-notebook.css').read()
HTML('<style>{}</style>'.format(css))


# In[4]:

titles = pd.DataFrame.from_csv('data/titles.csv', index_col=None)
titles.head()


# In[5]:

cast = pd.DataFrame.from_csv('data/cast.csv', index_col=None)
cast.head()


# In[ ]:




# ### Using groupby(), plot the number of films that have been released each decade in the history of cinema.

# In[18]:

titles['decade'] = titles.year // 10 * 10
titles.groupby('decade').size().plot()


# In[ ]:




# ### Use groupby() to plot the number of "Hamlet" films made each decade.

# In[17]:

h = titles[titles.title == 'Hamlet']
titles['decade'] = titles.year // 10 * 10
h.groupby('decade').size().plot()


# In[ ]:




# ### How many leading (n=1) roles were available to actors, and how many to actresses, in each year of the 1950s?

# In[55]:

actor = len(cast[(cast.n == 1) & (cast.year//10 == 195) & (cast.type == 'actor')])
actress = len(cast[(cast.n == 1) & (cast.year//10 == 195) & (cast.type == 'actress')])
actor + actress
#Number of total roles for actors & actresses


# In[54]:

c = cast[(cast.year//10 == 195) & (cast.n == 1)]
d = c.groupby(['year','type']).size().plot(kind='bar')


# ### In the 1950s decade taken as a whole, how many total roles were available to actors, and how many to actresses, for each "n" number 1 through 5?

# In[61]:

c = cast[(cast.year//10 == 195) & (cast.n < 6)]
d = c.groupby(['type','n']).size()#.plot(kind='bar')
d


# In[62]:

c = cast[(cast.year//10 == 195) & (cast.n < 6)]
d = c.groupby(['n','type']).size()#.plot(kind='bar')
d


# ### Use groupby() to determine how many roles are listed for each of the Pink Panther movies.

# In[65]:

c = cast[cast.title == 'The Pink Panther']
c = c.sort('n').groupby(['year'])[['n']].max()
c


# In[ ]:




# ### List, in order by year, each of the films in which Frank Oz has played more than 1 role.

# In[ ]:




# In[68]:

oz = cast[cast.name == 'Frank Oz']
oz = oz.groupby(['year','title']).size()
oz[oz > 1]


# In[ ]:




# ### List each of the characters that Frank Oz has portrayed at least twice.

# In[72]:

oz = cast[cast.name == 'Frank Oz']
oz = oz.groupby(['character']).size()
oz[oz > 1]


# In[ ]:



