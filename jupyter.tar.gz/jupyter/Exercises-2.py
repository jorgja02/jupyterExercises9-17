
# coding: utf-8

# In[ ]:

get_ipython().magic('matplotlib inline')
import pandas as pd
import seaborn as sbn


# In[ ]:

from IPython.core.display import HTML
css = open('style-table.css').read() + open('style-notebook.css').read()
HTML('<style>{}</style>'.format(css))


# In[ ]:

titles = pd.DataFrame.from_csv('data/titles.csv', index_col=None)
titles.head()


# In[ ]:




# In[ ]:

cast = pd.DataFrame.from_csv('data/cast.csv', index_col=None)
cast.head()


# ### What are the ten most common movie names of all time?

# In[ ]:

titles.title.value_counts().head(10)
        


# In[ ]:




# ### Which three years of the 1930s saw the most films released?

# In[ ]:

titles[titles.year // 10 == 193].year.value_counts().head(3)


# In[ ]:




# ### Plot the number of films that have been released each decade over the history of cinema.

# In[ ]:

#add a decade column
titles['decade'] = titles.year // 10 * 10
#titles.decade.value_counts()
#.sort_index() and .plot(kind='bar') WILL BE OF SERVICE
titles.decade.value_counts().sort_index().plot(kind='bar')


# In[ ]:




# ### Plot the number of "Hamlet" films made each decade.

# In[ ]:


titles['decade'] = titles.year // 10 * 10
Hamlet = titles[titles.title == 'Hamlet']
Hamlet.decade.value_counts().sort_index().plot(kind='bar')
Hamlet


# In[ ]:




# ### Plot the number of "Rustler" characters in each decade of the history of film.

# In[ ]:

#titles.decade.value_counts()#.sort_index().plot(kind='bar')
cast['decade'] = cast.year // 10 * 10
achar = cast[cast.character == 'Rustler']
achar.decade.value_counts().sort_index().plot(kind='bar')


# In[ ]:




# ### Plot the number of "Hamlet" characters each decade.

# In[ ]:

cast['decade'] = cast.year // 10 * 10
achar = cast[cast.character == 'Hamlet']
achar.decade.value_counts().sort_index().plot(kind='bar')


# In[ ]:




# ### What are the 11 most common character names in movie history?

# In[ ]:

cast.character.value_counts().head(10)


# In[ ]:




# ### Who are the 10 people most often credited as "Herself" in film history?

# In[ ]:

Herself = cast[cast.character == "Herself"]
Herself.name.value_counts().head(10)


# In[ ]:




# ### Who are the 10 people most often credited as "Himself" in film history?

# In[ ]:

Herself = cast[cast.character == "Himself"]
Herself.name.value_counts().head(10)


# In[ ]:




# ### Which actors or actresses appeared in the most movies in the year 1945?

# In[ ]:

c = cast[cast.year == 1945]
c.name.value_counts().head(10)


# In[ ]:




# ### Which actors or actresses appeared in the most movies in the year 1985?

# In[ ]:

c = cast[cast.year == 1985]
c.name.value_counts().head(10)


# In[ ]:




# ### Plot how many roles Mammootty has played in each year of his career.

# In[ ]:

c = cast[cast.name == 'Mammootty']
c.plot(kind='scatter',x='year',y='n',alpha=0.5)


# In[ ]:




# ### What are the 10 most frequent roles that start with the phrase "Patron in"?

# In[ ]:

c = cast[cast.character.str.startswith('Patron In')]
c.character.value_counts().head(10)


# In[ ]:




# ### What are the 10 most frequent roles that start with the word "Science"?

# In[ ]:

c = cast[cast.character.str.startswith('Science')] #startswith or contains
c.character.value_counts().head(10)


# In[ ]:




# ### Plot the n-values of the roles that Judi Dench has played over her career.

# In[ ]:

c = cast[cast.name == 'Judi Dench']
#c.n.value_counts().sort_index().plot(kind='bar')
c.plot(kind='scatter',x='year',y='n',alpha=0.5) #alpha adds density; "more than 1 dot there"


# In[ ]:

c = cast[cast.name == 'Judi Dench']
d = c.groupby(['year','n']).size()
d = d.unstack('n')
d.fillna(' ')


# ### Plot the n-values of Cary Grant's roles through his career.

# In[ ]:

c = cast[cast.name == 'Cary Grant']
d = c.groupby(['year','n']).size()
d = d.unstack('n')
d.fillna(' ')


# In[ ]:




# ### Plot the n-value of the roles that Sidney Poitier has acted over the years.

# In[ ]:

c = cast[cast.name == 'Sidney Poitier']
d = c.groupby(['year','n']).size()
d = d.unstack('n')
d.fillna(' ')


# In[ ]:




# ### How many leading (n=1) roles were available to actors, and how many to actresses, in the 1950s?

# In[ ]:

actor = len(cast[(cast.n == 1) & (cast.year//10 <= 196) & (cast.type == 'actor')])
actress = len(cast[(cast.n == 1) & (cast.year//10 <= 196) & (cast.type == 'actress')])
actor + actress


# In[ ]:




# ### How many supporting (n=2) roles were available to actors, and how many to actresses, in the 1950s?

# In[ ]:

actor = len(cast[(cast.n == 2) & (cast.year//10 <= 196) & (cast.type == 'actor')])
actress = len(cast[(cast.n == 2) & (cast.year//10 <= 196) & (cast.type == 'actress')])
actor + actress


# In[ ]:




# In[ ]:




# In[ ]:




# #Scratch Work

# In[ ]:

len(cast[(cast.title == 'Around the World in Eighty Days') & (cast.n.isnull())])


# In[ ]:

titles[titles.title == 'Around the World in Eighty Days']


# In[215]:

#cast.title.value_counts().tail()
#cast[cast.name == 'Robert Redford'].title.value_counts()

oneactor = cast.title.value_counts()[cast.title.value_counts() == 1]
c = cast[cast.name == 'Robert Redford']
#'The Link' in oneactor
for i in c.title:
    if i in oneactor:
        print(i)


# In[187]:

#oneactor = cast.title.value_counts()[cast.title.value_counts() == 1]
redford = cast[cast.name == 'Robert Redford'].title
cast[cast.title.isin(redford)].title.value_counts().tail(5)


# In[ ]:



