
# coding: utf-8

# In[1]:

get_ipython().magic('matplotlib inline')
import pandas as pd


# In[2]:

from IPython.core.display import HTML
css = open('style-table.css').read() + open('style-notebook.css').read()
HTML('<style>{}</style>'.format(css))


# In[3]:

titles = pd.DataFrame.from_csv('data/titles.csv', index_col=None)
titles.head()


# In[4]:

cast = pd.DataFrame.from_csv('data/cast.csv', index_col=None)
cast.head()


# In[ ]:




# ### Define a year as a "Superman year" whose films feature more Superman characters than Batman. How many years in film history have been Superman years?

# In[22]:

#Needs the unstack method
c = cast[(cast.character == 'Superman') | (cast.character == 'Batman')]
d = c.groupby(['year','character']).size().unstack('character').fillna(0)
d[d.Superman > d.Batman]


# In[ ]:




# ### How many years have been "Batman years", with more Batman characters than Superman characters?

# In[27]:

#Needs the unstack method
c = cast[(cast.character == 'Superman') | (cast.character == 'Batman')]
d = c.groupby(['year','character']).size().unstack('character').fillna(0)
e = d[d.Superman < d.Batman]
len(e)


# In[ ]:




# ### Plot the number of actor roles each year and the number of actress roles each year over the history of film.

# In[28]:

c = cast.groupby(['year','type']).size().unstack('type')
c.plot()


# In[ ]:




# ### Plot the number of actor roles each year and the number of actress roles each year, but this time as a kind='area' plot.

# In[29]:

c = cast.groupby(['year','type']).size().unstack('type')
c.plot(kind='area')


# In[ ]:




# ### Plot the difference between the number of actor roles each year and the number of actress roles each year over the history of film.

# In[30]:

c = cast.groupby(['year','type']).size().unstack('type')
(c.actor - c.actress).plot()


# In[ ]:




# ### Plot the fraction of roles that have been 'actor' roles each year in the hitsory of film.

# In[33]:

c = cast.groupby(['year','type']).size().unstack('type')
(c.actor / (c.actor + c.actress)).plot()


# In[ ]:




# ### Plot the fraction of supporting (n=2) roles that have been 'actor' roles each year in the history of film.

# In[35]:

c = cast[cast.n == 2]
c = c.groupby(['year','type']).size().unstack('type')
(c.actor / (c.actor + c.actress)).plot()


# In[ ]:




# ### Build a plot with a line for each rank n=1 through n=3, where the line shows what fraction of that rank's roles were 'actor' roles for each year in the history of film.

# In[37]:

c = cast[cast.n <= 3]
c = c.groupby(['year','type','n']).size().unstack('type')
role = (c.actor / (c.actor + c.actress)).unstack('n')
role.plot()


# In[ ]:



