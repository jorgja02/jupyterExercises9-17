
# coding: utf-8

# In[5]:

get_ipython().magic('matplotlib inline')
import pandas as pd


# In[85]:

from IPython.core.display import HTML
css = open('style-table.css').read() + open('style-notebook.css').read()
HTML('<style>{}</style>'.format(css))


# In[7]:

titles = pd.DataFrame.from_csv('data/titles.csv', index_col=None)
titles.head()


# In[8]:

cast = pd.DataFrame.from_csv('data/cast.csv', index_col=None)
cast.head()


# ### How many movies are listed in the titles dataframe?

# In[9]:

len(titles)
#https://github.com/brandon-rhodes/pycon-pandas-tutorial


# In[10]:

len(cast)


# ### What are the earliest two films listed in the titles dataframe?

# In[11]:

titles.sort('year').head(2)
#titles.head()


# In[12]:

#titles['yearssquared'] = titles['year'] * titles['year']
titles.head()


# ### How many movies have the title "Hamlet"?

# In[13]:

titles[titles.title == 'Hamlet']


# In[14]:

titles[(titles.title == 'Star Wars') | (titles.title == 'Dune')]


# ### How many movies are titled "North by Northwest"?

# In[15]:

titles[titles.title == 'North by Northwest']


# In[ ]:




# ### When was the first movie titled "Hamlet" made?

# In[16]:

titles[titles.title == 'Hamlet'].sort('year').head(1)


# In[ ]:




# ### List all of the "Treasure Island" movies from earliest to most recent.

# In[17]:

titles[titles.title == 'Treasure Island'].sort('year')


# In[ ]:




# ### How many movies were made in the year 1950?

# In[18]:

len(titles[titles.year == 1950])


# In[ ]:




# ### How many movies were made in the year 1960?

# In[19]:

len(titles[titles.year == 1960])


# In[ ]:




# ### How many movies were made from 1950 through 1959?

# In[20]:

len(titles[(titles.year == 1950) | (titles.year == 1951) | (titles.year == 1952) | (titles.year == 1953) | (titles.year == 1954) | (titles.year == 1955) | (titles.year == 1956) | (titles.year == 1957) | (titles.year == 1958) | (titles.year == 1959)])


# In[ ]:




# ### In what years has a movie titled "Batman" been released?

# In[21]:

titles[titles.title == 'Batman']['year']


# In[ ]:




# ### How many roles were there in the movie "Inception"?

# In[22]:

len(cast[cast.title == 'Inception'])


# In[ ]:




# ### How many roles in the movie "Inception" are NOT ranked by an "n" value?

# In[23]:

len(cast[(cast.title == 'Inception') & cast.n.isnull()])
#isnull or notnull


# In[ ]:




# ### But how many roles in the movie "Inception" did receive an "n" value?

# In[24]:

len(cast[(cast.title == 'Inception') & cast.n.notnull()])
#isnull or notnull


# In[ ]:




# ### Display the cast of "North by Northwest" in their correct "n"-value order, ignoring roles that did not earn a numeric "n" value.

# In[45]:

North = cast[(cast.title == 'North by Northwest') & cast.n.notnull()]
North.sort('n')


# In[ ]:




# ### Display the entire cast, in "n"-order, of the 1972 film "Sleuth".

# In[51]:

Sleuth = cast[(cast.title == 'Sleuth') & (cast.year == 1972)]
Sleuth.sort('n')


# In[ ]:




# In[ ]:




# ### Now display the entire cast, in "n"-order, of the 2007 version of "Sleuth".

# In[52]:

Sleuth = cast[(cast.title == 'Sleuth') & (cast.year == 2007)]
Sleuth.sort('n')


# In[ ]:




# ### How many roles were credited in the silent 1921 version of Hamlet?

# In[53]:

Hamlet = cast[cast.title == 'Hamlet']
Hamlet1921 = Hamlet[(Hamlet.year == 1921) & Hamlet.n.notnull()]
len(Hamlet1921)


# In[ ]:




# ### How many roles were credited in Branagh’s 1996 Hamlet?

# In[27]:

Hamlet = cast[cast.title == 'Hamlet']
Hamlet1996 = Hamlet[(Hamlet.year == 1996) & Hamlet.n.notnull()]
len(Hamlet1996)


# In[ ]:




# ### How many "Hamlet" roles have been listed in all film credits through history?

# In[59]:

len(cast[(cast.character == 'Hamlet') & cast.n.notnull()])


# In[ ]:




# ### How many people have played an "Ophelia"?

# In[29]:

len(cast[cast.character == 'Ophelia'])


# In[ ]:




# ### How many people have played a role called "The Dude"?

# In[30]:

len(cast[cast.character == 'The Dude'])


# In[ ]:




# ### How many people have played a role called "The Stranger"?

# In[31]:

len(cast[cast.character == 'The Stranger'])


# In[ ]:




# ### How many roles has Sidney Poitier played throughout his career?

# In[32]:

len(cast[cast.name == 'Sidney Poitier'])


# In[ ]:




# ### How many roles has Judi Dench played?

# In[33]:

len(cast[cast.name == 'Judi Dench'])


# In[ ]:




# ### List the supporting roles (having n=2) played by Cary Grant in the 1940s, in order by year.

# In[34]:

c = cast[(cast.n == 2) & (cast.name == 'Cary Grant') & (cast.year//10 == 194)]
c.sort('year')


# In[ ]:




# ### List the leading roles that Cary Grant played in the 1940s in order by year.

# In[35]:

c = cast[(cast.n == 1) & (cast.name == 'Cary Grant') & (cast.year//10 == 194)]
c.sort('year')


# In[ ]:




# ### How many roles were available for actors in the 1950s?

# In[36]:

cast1950s = cast[(cast.year == 1950)|(cast.year == 1951)|(cast.year == 1952)|(cast.year == 1953)|(cast.year == 1954)|(cast.year == 1955)|(cast.year == 1956)|(cast.year == 1957)|(cast.year == 1958)|(cast.year == 1959)]
len(cast1950s[cast1950s.type == 'actor'])


# In[ ]:




# ### How many roles were avilable for actresses in the 1950s?

# In[37]:

cast1950s = cast[(cast.year == 1950)|(cast.year == 1951)|(cast.year == 1952)|(cast.year == 1953)|(cast.year == 1954)|(cast.year == 1955)|(cast.year == 1956)|(cast.year == 1957)|(cast.year == 1958)|(cast.year == 1959)]
len(cast1950s[cast1950s.type == 'actress'])


# In[ ]:




# ### How many leading roles (n=1) were available from the beginning of film history through 1980?

# In[73]:

len(cast[(cast.n == 1) & (cast.year//10 <= 197)]) + len(cast[(cast.n == 1) & (cast.year == 1980)])


# In[ ]:




# ### How many non-leading roles were available through from the beginning of film history through 1980?

# In[74]:

len(cast[(cast.n > 1) & (cast.year//10 <= 197)]) + len(cast[(cast.n > 1) & (cast.year == 1980)])


# In[ ]:




# ### How many roles through 1980 were minor enough that they did not warrant a numeric "n" rank?

# In[84]:

len(cast[(cast.n.isnull()) & (cast.year//10 <= 197)]) + len(cast[(cast.n.isnull()) & (cast.year == 1980)])


# In[ ]:




# In[ ]:



