
# coding: utf-8

# In[2]:

get_ipython().magic('matplotlib inline')
import pandas as pd


# In[3]:

from IPython.core.display import HTML
css = open('style-table.css').read() + open('style-notebook.css').read()
HTML('<style>{}</style>'.format(css))


# In[4]:

cast = pd.DataFrame.from_csv('data/cast.csv', index_col=None)
cast.head()


# In[5]:

release_dates = pd.DataFrame.from_csv('data/release_dates.csv', index_col=None,
                                      parse_dates=['date'], infer_datetime_format=True)
release_dates.head()


# In[ ]:




# ### Make a bar plot of the months in which movies with "Christmas" in their title tend to be released in the USA.

# In[7]:

xmas = release_dates[release_dates.title.str.contains('Christmas')]
xmas = xmas[xmas.country == 'USA']
xmas.date.dt.month.value_counts().sort_index().plot(kind='bar')


# In[ ]:




# ### Make a bar plot of the months in which movies whose titles start with "The Hobbit" are released in the USA.

# In[8]:

hobbit = release_dates[release_dates.title.str.startswith('The Hobbit')]
hobbit = hobbit[hobbit.country == 'USA']
hobbit.date.dt.month.value_counts().sort_index().plot(kind='bar')


# In[ ]:




# ### Make a bar plot of the day of the week on which movies with "Romance" in their title tend to be released in the USA.

# In[9]:

luv = release_dates[release_dates.title.str.contains('Romance')]
luv = luv[luv.country == 'USA']
luv.date.dt.dayofweek.value_counts().sort_index().plot(kind='bar')


# In[ ]:




# ### Make a bar plot of the day of the week on which movies with "Action" in their title tend to be released in the USA.

# In[11]:

tnt = release_dates[release_dates.title.str.contains('Action')]
tnt = tnt[tnt.country == 'USA']
tnt.date.dt.dayofweek.value_counts().sort_index().plot(kind='bar')


# In[ ]:




# ### On which date was each Judi Dench movie from the 1990s released in the USA?

# In[16]:

d = cast[cast.name == 'Judi Dench']
d = d[d.year // 10 == 199]
d.merge(release_dates[release_dates.country == 'USA']).sort('date')


# In[ ]:




# ### In which months do films with Judi Dench tend to be released in the USA?

# In[17]:

d = cast[cast.name == 'Judi Dench']
m = d.merge(release_dates[release_dates.country == 'USA']).sort('date')
m.date.dt.month.value_counts().sort_index().plot()


# In[ ]:




# ### In which months do films with Tom Cruise tend to be released in the USA?

# In[18]:

d = cast[cast.name == 'Tom Cruise']
m = d.merge(release_dates[release_dates.country == 'USA']).sort('date')
m.date.dt.month.value_counts().sort_index().plot()


# In[ ]:



